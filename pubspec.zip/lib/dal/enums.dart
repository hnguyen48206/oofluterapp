enum KindAction {
  WeekCalendar,
  DiscussWork,
  WorkProjectNguoiXuLy,
  WorkProjectNguoiDuocXem,
  WorkProjectNguoiChuyenTiep,
  WorkProjectNguoiXuLyAdditional,
  WorkProjectNguoiDuocXemAdditional,
  DocumentNguoiDuocXem,
  Project,
  DocumentLuuBanCung,
  DocumentSource,
  DocumentDirectories,
  Announcement
}

enum IndexTabHome {
  Dashboard,
  CalendarWeek,
  WorkProject,
  DiscussWork,
  Document,
  More
}

enum IndexBadgeApp {
  Calendar,
  WorkProject,
  DiscussWork,
  Document,
  Announcement,
  ReportDaily,
  Library,
  Signature,
  TotalApp
}
